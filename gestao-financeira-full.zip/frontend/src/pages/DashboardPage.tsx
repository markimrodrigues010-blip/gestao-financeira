
export default function DashboardPage(){
  return <h1 style={{color:"white"}}>Dashboard</h1>
}
